import 'package:flutter/material.dart';


const kPadding = 14;

var khoverColor = Colors.white.withOpacity(0.15);
var kbuttonNewColor = Colors.pink.shade300;
var kboxBgColors = Colors.grey.shade300;