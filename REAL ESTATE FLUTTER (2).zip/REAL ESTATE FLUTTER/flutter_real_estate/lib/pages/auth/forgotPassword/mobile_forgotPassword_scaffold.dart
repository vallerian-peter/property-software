import 'package:flutter/material.dart';

class MobileForgotpasswordScaffold extends StatefulWidget {
  const MobileForgotpasswordScaffold({super.key});

  @override
  State<MobileForgotpasswordScaffold> createState() => _MobileForgotpasswordScaffoldState();
}

class _MobileForgotpasswordScaffoldState extends State<MobileForgotpasswordScaffold> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
