import 'package:flutter/material.dart';

class MinTabletForgotpasswordScaffold extends StatefulWidget {
  const MinTabletForgotpasswordScaffold({super.key});

  @override
  State<MinTabletForgotpasswordScaffold> createState() => _MinTabletForgotpasswordScaffoldState();
}

class _MinTabletForgotpasswordScaffoldState extends State<MinTabletForgotpasswordScaffold> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
