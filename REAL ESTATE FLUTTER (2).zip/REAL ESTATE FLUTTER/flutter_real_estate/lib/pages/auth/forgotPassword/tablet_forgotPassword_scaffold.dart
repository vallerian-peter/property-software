import 'package:flutter/material.dart';

class TabletForgotpasswordScaffold extends StatefulWidget {
  const TabletForgotpasswordScaffold({super.key});

  @override
  State<TabletForgotpasswordScaffold> createState() => _TabletForgotpasswordScaffoldState();
}

class _TabletForgotpasswordScaffoldState extends State<TabletForgotpasswordScaffold> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
